import dinasiriPhoto from "@/assets/dinasiri-photo.jpg";
import ScrollReveal from "./ScrollReveal";

const About = () => {
  return (
    <section id="about" className="section-padding">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <ScrollReveal direction="left">
            <div className="relative">
              <div className="relative z-10">
                <div className="aspect-square max-w-sm mx-auto lg:mx-0 rounded-full overflow-hidden bg-gradient-to-br from-accent to-[hsl(250,91%,68%)] p-1">
                  <img 
                    src={dinasiriPhoto} 
                    alt="Dinasiri Osman - Web Designer & Developer" 
                    className="w-full h-full rounded-full object-cover object-[center_15%] scale-150"
                  />
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-accent/20 rounded-full blur-2xl"></div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-[hsl(250,91%,68%)]/20 rounded-full blur-2xl"></div>
            </div>
          </ScrollReveal>

          {/* Content */}
          <ScrollReveal direction="right" delay={0.2}>
            <div className="space-y-6">
              <div>
                <span className="text-accent font-semibold text-sm uppercase tracking-wider">About Me</span>
                <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2">
                  Passionate About Creating <span className="gradient-text">Amazing</span> Web Experiences
                </h2>
              </div>
              
              <p className="text-muted-foreground text-lg leading-relaxed">
                Hi, I'm <strong className="text-primary">Dinasiri Osman</strong>, a freelance web designer and developer. 
                I create clean, modern, and responsive websites that help businesses attract customers and build trust online.
              </p>
              
              <p className="text-muted-foreground leading-relaxed">
                My focus is on performance, usability, and professional design. Whether you need a brand new website, 
                a redesign of your existing one, or a high-converting landing page, I'm here to help your business 
                succeed in the digital world.
              </p>

              <div className="grid grid-cols-2 gap-6 pt-4">
                <div className="p-4 bg-secondary rounded-xl">
                  <div className="text-2xl font-bold text-accent">100%</div>
                  <div className="text-sm text-muted-foreground">Client Satisfaction</div>
                </div>
                <div className="p-4 bg-secondary rounded-xl">
                  <div className="text-2xl font-bold text-accent">24/7</div>
                  <div className="text-sm text-muted-foreground">Support Available</div>
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
};

export default About;
