import { Button } from "./ui/button";
import { ArrowRight } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const CTA = () => {
  return (
    <section className="py-20">
      <div className="container-custom">
        <ScrollReveal>
          <div className="relative overflow-hidden rounded-3xl gradient-bg p-8 md:p-16 text-center">
            {/* Background decoration */}
            <div className="absolute inset-0 opacity-30">
              <div className="absolute top-0 left-1/4 w-64 h-64 bg-white/20 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
            </div>
            
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
                Ready to Build a Professional <br className="hidden md:block" />
                Website for Your Business?
              </h2>
              <p className="text-white/80 text-lg max-w-2xl mx-auto mb-8">
                Let's work together to create a website that attracts customers, builds trust, and grows your business online.
              </p>
              <Button 
                size="xl" 
                className="bg-white text-primary hover:bg-white/90 font-semibold shadow-xl hover:shadow-2xl hover:scale-[1.02] transition-all duration-300"
                asChild
              >
                <a href="#contact" className="group">
                  Get in Touch
                  <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                </a>
              </Button>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};

export default CTA;
