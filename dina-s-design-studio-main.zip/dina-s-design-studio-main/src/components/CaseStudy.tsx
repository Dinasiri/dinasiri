import { Target, AlertCircle, Lightbulb, Wrench, Trophy, ExternalLink } from "lucide-react";
import { Button } from "./ui/button";
import projectRora from "@/assets/project-rora-screenshot.png";
import ScrollReveal from "./ScrollReveal";

const CaseStudy = () => {
  return (
    <section className="section-padding">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm uppercase tracking-wider">Case Study</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2">
              Featured <span className="gradient-text">Project</span>
            </h2>
            <p className="text-muted-foreground mt-4">
              A detailed look at how I helped transform a client's vision into reality.
            </p>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={0.2}>
          <div className="bg-card rounded-3xl overflow-hidden card-shadow">
            {/* Project Image */}
            <div className="aspect-video lg:aspect-[21/9] overflow-hidden">
              <img 
                src={projectRora} 
                alt="RORA Lagos Restaurant Website"
                className="w-full h-full object-cover object-top"
              />
            </div>

            {/* Project Details */}
            <div className="p-8 lg:p-12">
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <h3 className="text-2xl lg:text-3xl font-bold text-primary">RORA Lagos Restaurant & Lounge</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.open('https://rora-lagos-showcase-mwfd.vercel.app', '_blank')}
                >
                  View Live <ExternalLink className="w-4 h-4 ml-1" />
                </Button>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8">
                {/* Goal */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-accent">
                    <Target className="w-5 h-5" />
                    <span className="font-semibold text-sm uppercase tracking-wider">Goal</span>
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Create a stunning online presence for a premium restaurant and lounge in Victoria Island, Lagos to attract upscale clientele and enable online reservations.
                  </p>
                </div>

                {/* Problem */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-orange-500">
                    <AlertCircle className="w-5 h-5" />
                    <span className="font-semibold text-sm uppercase tracking-wider">Problem</span>
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    The client had no digital presence and was losing potential customers to competitors with established online booking systems and social media visibility.
                  </p>
                </div>

                {/* Solution */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-green-500">
                    <Lightbulb className="w-5 h-5" />
                    <span className="font-semibold text-sm uppercase tracking-wider">Solution</span>
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Designed a luxury-themed website with an integrated reservation system, menu showcase, gallery, and contact integration for seamless customer engagement.
                  </p>
                </div>

                {/* Tools */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-blue-500">
                    <Wrench className="w-5 h-5" />
                    <span className="font-semibold text-sm uppercase tracking-wider">Tools Used</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {["React", "Tailwind CSS", "TypeScript", "Vercel"].map((tool) => (
                      <span
                        key={tool}
                        className="px-2 py-1 bg-secondary rounded-md text-xs font-medium text-muted-foreground"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Results */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-purple-500">
                    <Trophy className="w-5 h-5" />
                    <span className="font-semibold text-sm uppercase tracking-wider">Results</span>
                  </div>
                  <ul className="text-muted-foreground text-sm space-y-1">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent"></span>
                      Increased online visibility
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent"></span>
                      Streamlined reservations
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent"></span>
                      Professional brand image
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};

export default CaseStudy;