import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import ScrollReveal from "./ScrollReveal";

const faqs = [
  {
    question: "How long does it take to build a website?",
    answer: "Most websites take between 1-3 weeks depending on complexity. A simple landing page can be done in 3-5 days, while a full business website with multiple pages typically takes 2-3 weeks. I'll provide a specific timeline during our initial consultation."
  },
  {
    question: "What is your pricing structure?",
    answer: "I offer project-based pricing tailored to your specific needs. A basic landing page starts from $100, while full business websites range from $300-$1,000+ depending on features and complexity. I provide a detailed quote after understanding your requirements."
  },
  {
    question: "How many revisions are included?",
    answer: "All my projects include 2-3 rounds of revisions to ensure you're completely satisfied with the final result. I work closely with you throughout the process to minimize the need for major changes."
  },
  {
    question: "Do you provide support after launch?",
    answer: "Yes! I offer 30 days of free support after launch to fix any bugs and make minor adjustments. For ongoing maintenance, I offer affordable monthly support packages to keep your website secure and up-to-date."
  },
  {
    question: "Will my website be mobile-friendly?",
    answer: "Absolutely! Every website I build is fully responsive and optimized for all devices - smartphones, tablets, and desktops. Mobile-first design is a standard part of my development process."
  },
  {
    question: "Can you help with SEO and getting found on Google?",
    answer: "Yes, I implement SEO best practices on every website including proper meta tags, fast loading speeds, mobile optimization, and clean code structure. For advanced SEO strategies, I can recommend trusted specialists."
  },
  {
    question: "Do I need to provide content and images?",
    answer: "You'll need to provide your business information, text content, and any specific images you want to use. I can help with stock photos, icons, and can assist with content structure if needed."
  },
  {
    question: "What do you need from me to get started?",
    answer: "To get started, I need: your business information, brand assets (logo, colors), reference websites you like, content/text for pages, and any specific features you require. We'll discuss everything in detail during our first call."
  },
];

const FAQs = () => {
  return (
    <section className="section-padding bg-secondary/30">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm uppercase tracking-wider">FAQs</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2">
              Frequently Asked <span className="gradient-text">Questions</span>
            </h2>
            <p className="text-muted-foreground mt-4">
              Get answers to common questions about working with me.
            </p>
          </div>
        </ScrollReveal>

        <ScrollReveal delay={0.2}>
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card rounded-xl px-6 border-none card-shadow"
                >
                  <AccordionTrigger className="text-left text-primary font-medium hover:no-underline py-5">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground pb-5 leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
};

export default FAQs;