import { useState } from "react";
import { X, Play, ChevronLeft, ChevronRight } from "lucide-react";
import projectPlumbing from "@/assets/project-plumbing.png";
import projectRora from "@/assets/project-rora-screenshot.png";
import beforeAfterVideo from "@/assets/before-after-video.mp4";
import ScrollReveal from "./ScrollReveal";

const galleryItems = [
  {
    type: "image",
    src: projectPlumbing,
    title: "Guest Plumbing & HVAC",
    description: "Professional plumbing services website",
  },
  {
    type: "image",
    src: projectRora,
    title: "RORA Lagos",
    description: "Luxury restaurant & lounge website",
  },
  {
    type: "video",
    src: beforeAfterVideo,
    title: "Website Transformation",
    description: "See the before & after of our redesigns",
  },
];

const Gallery = () => {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const openLightbox = (index: number) => {
    setCurrentIndex(index);
    setLightboxOpen(true);
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? galleryItems.length - 1 : prev - 1));
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev === galleryItems.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="gallery" className="section-padding">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-primary font-semibold text-sm uppercase tracking-wider">Gallery</span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2">
              Project <span className="gradient-text">Showcase</span>
            </h2>
            <p className="text-muted-foreground mt-4">
              Browse through my recent work and see the transformation
            </p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryItems.map((item, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <div
                onClick={() => openLightbox(index)}
                className="group relative aspect-video rounded-xl overflow-hidden cursor-pointer card-shadow hover:card-shadow-hover transition-all duration-300"
              >
                {item.type === "image" ? (
                  <img
                    src={item.src}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                ) : (
                  <div className="relative w-full h-full bg-secondary">
                    <video
                      src={item.src}
                      className="w-full h-full object-cover"
                      muted
                      playsInline
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-foreground/30">
                      <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Play className="w-6 h-6 text-primary-foreground ml-1" fill="white" />
                      </div>
                    </div>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-white font-semibold">{item.title}</h3>
                    <p className="text-white/80 text-sm">{item.description}</p>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && (
        <div className="fixed inset-0 z-50 bg-foreground/95 flex items-center justify-center p-4">
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          <button
            onClick={goToPrevious}
            className="absolute left-4 w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={goToNext}
            className="absolute right-4 w-12 h-12 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="max-w-5xl w-full">
            {galleryItems[currentIndex].type === "image" ? (
              <img
                src={galleryItems[currentIndex].src}
                alt={galleryItems[currentIndex].title}
                className="w-full rounded-xl"
              />
            ) : (
              <video
                src={galleryItems[currentIndex].src}
                controls
                autoPlay
                className="w-full rounded-xl"
              />
            )}
            <div className="text-center mt-4">
              <h3 className="text-white font-semibold text-xl">{galleryItems[currentIndex].title}</h3>
              <p className="text-white/70">{galleryItems[currentIndex].description}</p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Gallery;