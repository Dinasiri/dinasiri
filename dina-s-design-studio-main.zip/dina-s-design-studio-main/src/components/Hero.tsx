import { Button } from "./ui/button";
import { ArrowRight, ExternalLink } from "lucide-react";

const Hero = () => {
  return (
    <section className="min-h-screen flex items-center pt-20 md:pt-0 overflow-hidden">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-slide-in-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-accent/10 rounded-full text-accent text-sm font-medium">
              <span className="w-2 h-2 bg-accent rounded-full animate-pulse"></span>
              Available for Freelance Work
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-primary">
              I Design Modern,{" "}
              <span className="gradient-text">High-Converting</span>{" "}
              Websites for Businesses
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-lg">
              I help businesses grow online with fast, responsive, and professional websites that attract customers and build trust.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="hero" asChild>
                <a href="#portfolio" className="group">
                  View My Work
                  <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                </a>
              </Button>
              <Button variant="heroOutline" asChild>
                <a href="#contact">
                  Contact Me
                </a>
              </Button>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-4">
              <div>
                <div className="text-3xl font-bold text-primary">50+</div>
                <div className="text-sm text-muted-foreground">Projects Done</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary">30+</div>
                <div className="text-sm text-muted-foreground">Happy Clients</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary">3+</div>
                <div className="text-sm text-muted-foreground">Years Experience</div>
              </div>
            </div>
          </div>

          {/* Right Content - Mockup */}
          <div className="relative animate-slide-in-right">
            <div className="relative z-10">
              {/* Browser Mockup */}
              <div className="bg-primary rounded-2xl p-2 shadow-2xl">
                <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  </div>
                  <div className="flex-1 flex justify-center">
                    <div className="bg-white/10 rounded-lg px-4 py-1 text-xs text-white/60 flex items-center gap-2">
                      <ExternalLink size={12} />
                      yourwebsite.com
                    </div>
                  </div>
                </div>
                <div className="aspect-[4/3] bg-gradient-to-br from-accent/20 to-[hsl(250,91%,68%)]/20 rounded-xl overflow-hidden">
                  <div className="h-full flex flex-col">
                    <div className="flex-1 p-6 flex flex-col justify-center items-center text-center">
                      <div className="w-16 h-16 rounded-2xl gradient-bg mb-4 flex items-center justify-center">
                        <span className="text-2xl">🚀</span>
                      </div>
                      <h3 className="text-white font-bold text-xl mb-2">Your Next Website</h3>
                      <p className="text-white/60 text-sm max-w-xs">
                        Modern, fast, and designed to convert visitors into customers
                      </p>
                    </div>
                    <div className="p-4 bg-white/5 grid grid-cols-3 gap-3">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-16 bg-white/10 rounded-lg"></div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Background decorations */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-accent/30 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-[hsl(250,91%,68%)]/20 rounded-full blur-3xl"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
