import { ExternalLink } from "lucide-react";
import { Button } from "./ui/button";
import projectPlumbing from "@/assets/project-plumbing.png";
import projectRora from "@/assets/project-rora-screenshot.png";
import ScrollReveal from "./ScrollReveal";

const projects = [
  {
    title: "Guest Plumbing & HVAC",
    description: "Professional plumbing and HVAC services website with quote forms, service listings, and emergency contact features for Hamilton area customers.",
    tech: ["React", "Tailwind CSS", "Responsive", "Lead Generation"],
    image: projectPlumbing,
    liveUrl: "https://guest-plumbing-s-website.vercel.app",
  },
  {
    title: "RORA Lagos Restaurant & Lounge",
    description: "Elegant restaurant and lounge website featuring reservation system, menu showcase, and stunning poolside ambiance for Victoria Island, Lagos.",
    tech: ["React", "Modern UI", "Reservation System", "SEO"],
    image: projectRora,
    liveUrl: "https://rora-lagos-showcase-mwfd.vercel.app",
  },
];

const Portfolio = () => {
  return (
    <section id="portfolio" className="section-padding bg-secondary/30">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm uppercase tracking-wider">My Work</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2">
              Featured <span className="gradient-text">Projects</span>
            </h2>
            <p className="text-muted-foreground mt-4">
              A selection of websites I've designed and developed for clients across different industries.
            </p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {projects.map((project, index) => (
            <ScrollReveal key={index} delay={index * 0.15}>
              <div className="group bg-card rounded-2xl overflow-hidden card-shadow hover:card-shadow-hover transition-all duration-300 hover:-translate-y-2 h-full">
                {/* Project Image */}
                <div className="aspect-video overflow-hidden bg-secondary">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                
                {/* Project Info */}
                <div className="p-6 lg:p-8">
                  <h3 className="text-xl font-semibold text-primary mb-2">{project.title}</h3>
                  <p className="text-muted-foreground mb-4">{project.description}</p>
                  
                  {/* Tech Stack */}
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tech.map((tech, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 bg-secondary rounded-full text-xs font-medium text-muted-foreground"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="group/btn"
                    onClick={() => window.open(project.liveUrl, '_blank')}
                  >
                    View Live Site
                    <ExternalLink className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;