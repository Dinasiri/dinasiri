import { 
  Layout, 
  Store, 
  FileText, 
  RefreshCcw, 
  Smartphone, 
  Gauge 
} from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const services = [
  {
    icon: Layout,
    title: "Website Design & Development",
    description: "Modern and professional websites that represent your brand and engage visitors effectively.",
  },
  {
    icon: Store,
    title: "Business & Restaurant Websites",
    description: "Designed to attract local and international customers with stunning visuals and easy navigation.",
  },
  {
    icon: FileText,
    title: "Landing Pages",
    description: "Conversion-focused pages for marketing campaigns that turn visitors into customers.",
  },
  {
    icon: RefreshCcw,
    title: "Website Redesign",
    description: "Transform your outdated or slow website into a modern, fast-loading experience.",
  },
  {
    icon: Smartphone,
    title: "Mobile Optimization",
    description: "Perfect experience on all devices - phones, tablets, and desktops.",
  },
  {
    icon: Gauge,
    title: "Performance & SEO",
    description: "Fast loading speeds and search-friendly structure to boost your online visibility.",
  },
];

const Services = () => {
  return (
    <section id="services" className="section-padding">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm uppercase tracking-wider">What I Offer</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2">
              Services That <span className="gradient-text">Grow</span> Your Business
            </h2>
            <p className="text-muted-foreground mt-4">
              From design to development, I provide end-to-end web solutions tailored to your needs.
            </p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <div className="group bg-card rounded-2xl p-8 card-shadow hover:card-shadow-hover transition-all duration-300 hover:-translate-y-2 border border-transparent hover:border-accent/20 h-full">
                <div className="w-14 h-14 rounded-xl gradient-bg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-primary mb-3">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{service.description}</p>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
