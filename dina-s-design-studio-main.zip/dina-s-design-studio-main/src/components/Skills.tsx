import { 
  Code2, 
  Palette, 
  FileCode, 
  Smartphone, 
  Search, 
  GitBranch,
  Globe,
  Layers
} from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const skills = [
  { name: "HTML", icon: FileCode },
  { name: "CSS", icon: Palette },
  { name: "JavaScript", icon: Code2 },
  { name: "React", icon: Layers },
  { name: "WordPress", icon: Globe },
  { name: "GitHub", icon: GitBranch },
  { name: "Responsive Design", icon: Smartphone },
  { name: "Basic SEO", icon: Search },
];

const Skills = () => {
  return (
    <section className="section-padding bg-secondary/30">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm uppercase tracking-wider">Skills & Tools</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2">
              Technologies I <span className="gradient-text">Work With</span>
            </h2>
            <p className="text-muted-foreground mt-4">
              I use modern technologies and tools to build fast, scalable, and maintainable websites.
            </p>
          </div>
        </ScrollReveal>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-6">
          {skills.map((skill, index) => (
            <ScrollReveal key={index} delay={index * 0.05}>
              <div className="group bg-card rounded-2xl p-6 text-center card-shadow hover:card-shadow-hover transition-all duration-300 hover:-translate-y-1 hover:bg-gradient-to-br hover:from-accent/5 hover:to-[hsl(250,91%,68%)]/5">
                <div className="w-14 h-14 mx-auto rounded-xl bg-secondary group-hover:gradient-bg flex items-center justify-center mb-4 transition-all duration-300">
                  <skill.icon className="w-7 h-7 text-accent group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="font-semibold text-primary">{skill.name}</h3>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
