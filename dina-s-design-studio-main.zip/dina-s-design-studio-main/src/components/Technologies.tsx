import { 
  Code2, 
  Palette, 
  FileCode, 
  Atom, 
  Globe, 
  Github, 
  Triangle 
} from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const technologies = [
  {
    name: "HTML5",
    icon: Code2,
    color: "from-orange-500 to-red-500",
  },
  {
    name: "CSS3",
    icon: Palette,
    color: "from-blue-500 to-indigo-500",
  },
  {
    name: "JavaScript",
    icon: FileCode,
    color: "from-yellow-400 to-amber-500",
  },
  {
    name: "React",
    icon: Atom,
    color: "from-cyan-400 to-blue-500",
  },
  {
    name: "WordPress",
    icon: Globe,
    color: "from-blue-600 to-indigo-600",
  },
  {
    name: "GitHub",
    icon: Github,
    color: "from-gray-600 to-gray-800",
  },
  {
    name: "Vercel",
    icon: Triangle,
    color: "from-gray-700 to-black",
  },
];

const Technologies = () => {
  return (
    <section className="section-padding">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm uppercase tracking-wider">Tech Stack</span>
            <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2">
              Technologies I <span className="gradient-text">Use</span>
            </h2>
            <p className="text-muted-foreground mt-4">
              Modern tools and frameworks to build fast, scalable, and beautiful websites.
            </p>
          </div>
        </ScrollReveal>

        <div className="flex flex-wrap justify-center gap-6 lg:gap-8">
          {technologies.map((tech, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <div className="group flex flex-col items-center">
                <div className={`w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-gradient-to-br ${tech.color} flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:shadow-xl transition-all duration-300`}>
                  <tech.icon className="w-10 h-10 md:w-12 md:h-12 text-white" />
                </div>
                <span className="mt-3 text-sm font-medium text-primary">{tech.name}</span>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Technologies;