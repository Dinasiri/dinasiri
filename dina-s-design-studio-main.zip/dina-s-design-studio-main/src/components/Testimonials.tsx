import { Quote, Star, Play, X } from "lucide-react";
import { useState } from "react";
import testimonialVideo from "@/assets/testimonial-video.mp4";
import beforeAfterVideo from "@/assets/before-after-video.mp4";
import ScrollReveal from "./ScrollReveal";

const testimonials = [
  {
    name: "Ahmed Hassan",
    role: "Restaurant Owner, Lagos",
    content: "Dinasiri transformed my restaurant's online presence completely. The new website is stunning, fast, and my customers love the online reservation feature. Bookings increased by 40%!",
    rating: 5,
  },
  {
    name: "Sarah Kimani",
    role: "Plumbing Business Owner, Kenya",
    content: "Professional, responsive, and delivered on time. The website helped my plumbing business get found on Google. I'm getting 3x more calls now!",
    rating: 5,
  },
  {
    name: "Michael Okonkwo",
    role: "E-commerce Entrepreneur",
    content: "My online store went from zero sales to profitable in just 2 months after the redesign. Fast delivery, great communication, and the final result exceeded my expectations.",
    rating: 5,
  },
];

const videoTestimonials = [
  {
    name: "Client Success Stories",
    description: "Watch what our clients say about working with us",
    video: testimonialVideo,
    thumbnail: null,
  },
  {
    name: "Website Transformation",
    description: "See the before & after of our redesigns",
    video: beforeAfterVideo,
    thumbnail: null,
  },
];

const Testimonials = () => {
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);

  return (
    <section className="section-padding">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-primary font-semibold text-sm uppercase tracking-wider">Testimonials</span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2">
              What <span className="gradient-text">Clients</span> Say
            </h2>
            <p className="text-muted-foreground mt-4">
              Don't just take my word for it - here's what my clients have to say about working with me.
            </p>
          </div>
        </ScrollReveal>

        {/* Text Testimonials */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <div className="relative bg-card rounded-xl p-8 card-shadow hover:card-shadow-hover transition-all duration-300 hover:-translate-y-1 h-full">
                <Quote className="absolute top-6 right-6 w-10 h-10 text-primary/20" />
                
                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                
                <p className="text-muted-foreground mb-6 italic leading-relaxed">
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-semibold">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>

        {/* Video Testimonials */}
        <ScrollReveal>
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-foreground">
              Video <span className="gradient-text">Testimonials</span>
            </h3>
            <p className="text-muted-foreground mt-2">Watch real client experiences and project transformations</p>
          </div>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 gap-6 lg:gap-8 max-w-4xl mx-auto">
          {videoTestimonials.map((item, index) => (
            <ScrollReveal key={index} delay={index * 0.15}>
              <div className="group relative bg-card rounded-xl overflow-hidden card-shadow hover:card-shadow-hover transition-all duration-300">
                <div className="aspect-video relative bg-secondary">
                  <video
                    src={item.video}
                    className="w-full h-full object-cover"
                    muted
                    playsInline
                    loop
                    onMouseEnter={(e) => e.currentTarget.play()}
                    onMouseLeave={(e) => {
                      e.currentTarget.pause();
                      e.currentTarget.currentTime = 0;
                    }}
                  />
                  <div 
                    className="absolute inset-0 bg-foreground/30 flex items-center justify-center cursor-pointer group-hover:bg-foreground/40 transition-colors"
                    onClick={() => setPlayingVideo(item.video)}
                  >
                    <button className="w-16 h-16 rounded-full bg-primary flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 text-primary-foreground ml-1" fill="white" />
                    </button>
                  </div>
                </div>
                <div className="p-4">
                  <div className="font-semibold text-foreground">{item.name}</div>
                  <div className="text-sm text-muted-foreground">{item.description}</div>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>

      {/* Video Modal */}
      {playingVideo && (
        <div 
          className="fixed inset-0 z-50 bg-foreground/95 flex items-center justify-center p-4"
          onClick={() => setPlayingVideo(null)}
        >
          <button
            onClick={() => setPlayingVideo(null)}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10"
          >
            <X className="w-6 h-6" />
          </button>
          <video
            src={playingVideo}
            controls
            autoPlay
            className="max-w-4xl w-full rounded-xl"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </section>
  );
};

export default Testimonials;