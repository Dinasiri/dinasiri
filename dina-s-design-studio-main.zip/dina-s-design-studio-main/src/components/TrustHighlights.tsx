import { Zap, Target, Search, Monitor } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const highlights = [
  {
    icon: Zap,
    title: "Fast & Mobile-Friendly",
    description: "Lightning-fast websites optimized for all devices",
  },
  {
    icon: Target,
    title: "Business-Focused Design",
    description: "Designed to attract customers and drive conversions",
  },
  {
    icon: Search,
    title: "SEO-Optimized",
    description: "Built with search engine visibility in mind",
  },
  {
    icon: Monitor,
    title: "Modern Technologies",
    description: "Using the latest tools for best performance",
  },
];

const TrustHighlights = () => {
  return (
    <section className="py-16 bg-secondary/50">
      <div className="container-custom">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((item, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <div className="group bg-card rounded-2xl p-6 card-shadow hover:card-shadow-hover transition-all duration-300 hover:-translate-y-1 h-full">
                <div className="w-12 h-12 rounded-xl gradient-bg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-primary mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustHighlights;
