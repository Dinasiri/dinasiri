import { Search, Palette, MessageSquare, Rocket } from "lucide-react";
import ScrollReveal from "./ScrollReveal";

const steps = [
  {
    icon: Search,
    title: "Planning & Discovery",
    description: "Understanding your goals, target audience, and requirements to create a solid foundation.",
  },
  {
    icon: Palette,
    title: "Design & Development",
    description: "Creating beautiful designs and bringing them to life with clean, efficient code.",
  },
  {
    icon: MessageSquare,
    title: "Review & Revisions",
    description: "Refining the design based on your feedback until it's exactly what you envisioned.",
  },
  {
    icon: Rocket,
    title: "Launch & Support",
    description: "Deploying your website and providing ongoing support to keep it running smoothly.",
  },
];

const WorkProcess = () => {
  return (
    <section className="section-padding bg-primary">
      <div className="container-custom">
        <ScrollReveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-accent font-semibold text-sm uppercase tracking-wider">How I Work</span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mt-2">
              My Work <span className="text-accent">Process</span>
            </h2>
            <p className="text-white/70 mt-4">
              A streamlined approach to deliver high-quality websites on time and within budget.
            </p>
          </div>
        </ScrollReveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <ScrollReveal key={index} delay={index * 0.15}>
              <div className="relative h-full">
                {/* Connector line */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-[calc(50%+2rem)] w-[calc(100%-4rem)] h-0.5 bg-white/20"></div>
                )}
                
                <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 text-center hover:bg-white/10 transition-all duration-300 h-full">
                  {/* Step Number */}
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full gradient-bg text-white text-xs font-bold flex items-center justify-center">
                    {index + 1}
                  </div>
                  
                  <div className="w-14 h-14 mx-auto rounded-xl bg-white/10 flex items-center justify-center mb-4">
                    <step.icon className="w-7 h-7 text-accent" />
                  </div>
                  
                  <h3 className="text-lg font-semibold text-white mb-2">{step.title}</h3>
                  <p className="text-white/60 text-sm leading-relaxed">{step.description}</p>
                </div>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WorkProcess;
