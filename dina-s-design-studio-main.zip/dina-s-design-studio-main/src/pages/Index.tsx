import Header from "@/components/Header";
import Hero from "@/components/Hero";
import TrustHighlights from "@/components/TrustHighlights";
import About from "@/components/About";
import WhyChooseMe from "@/components/WhyChooseMe";
import Skills from "@/components/Skills";
import Technologies from "@/components/Technologies";
import Services from "@/components/Services";
import Portfolio from "@/components/Portfolio";
import Gallery from "@/components/Gallery";
import CaseStudy from "@/components/CaseStudy";
import Testimonials from "@/components/Testimonials";
import WorkProcess from "@/components/WorkProcess";
import FAQs from "@/components/FAQs";
import CTA from "@/components/CTA";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <TrustHighlights />
      <About />
      <WhyChooseMe />
      <Skills />
      <Technologies />
      <Services />
      <Portfolio />
      <Gallery />
      <CaseStudy />
      <Testimonials />
      <WorkProcess />
      <FAQs />
      <CTA />
      <Contact />
      <Footer />
    </div>
  );
};

export default Index;